//
//  SecondViewController.swift
//  Rest Api
//
//  Created by Babek Gadirli on 19.11.21.
//

import UIKit

class SecondViewController: UIViewController {
    
    
    @IBOutlet weak var bigImage: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var bioLabel: UILabel!
    
    var poster = UIImage()
    var movieTitle: String = ""
    var movieBio: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  

}
